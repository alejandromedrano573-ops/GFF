/*
 GGL Football demo website.
 Data is saved to localStorage in this browser only. This is NOT a secure multi-user admin backend.
 Replace the sample data with verified league information before publishing.
*/
const seed = {
  games: [
    {week:"WEEK 01",date:"Oct 24 · 6:00 PM",away:"WOLVES",home:"HAWKS",awayScore:null,homeScore:null,status:"upcoming"},
    {week:"WEEK 01",date:"Oct 24 · 7:30 PM",away:"TITANS",home:"KNIGHTS",awayScore:null,homeScore:null,status:"upcoming"},
    {week:"WEEK 00",date:"Oct 17 · FINAL",away:"HAWKS",home:"KNIGHTS",awayScore:21,homeScore:17,status:"final"},
    {week:"WEEK 00",date:"Oct 17 · FINAL",away:"WOLVES",home:"TITANS",awayScore:14,homeScore:28,status:"final"}
  ],
  teams: [
    {name:"WOLVES",short:"W",division:"GGL CONFERENCE",wins:0,losses:0},
    {name:"HAWKS",short:"H",division:"GGL CONFERENCE",wins:1,losses:0},
    {name:"TITANS",short:"T",division:"GGL CONFERENCE",wins:1,losses:0},
    {name:"KNIGHTS",short:"K",division:"GGL CONFERENCE",wins:0,losses:1}
  ],
  players: [
    {name:"Jordan Carter",team:"HAWKS",pos:"QB",yards:248,td:3,tackles:0},
    {name:"Malik Brooks",team:"TITANS",pos:"RB",yards:42,td:2,tackles:1},
    {name:"Devin Price",team:"KNIGHTS",pos:"WR",yards:116,td:1,tackles:0},
    {name:"Cameron Reed",team:"WOLVES",pos:"LB",yards:0,td:0,tackles:9},
    {name:"Avery James",team:"TITANS",pos:"WR",yards:89,td:1,tackles:0},
    {name:"Taylor Morgan",team:"HAWKS",pos:"DB",yards:0,td:0,tackles:6}
  ],
  awards: [
    {name:"Most Valuable Player",desc:"The season's most impactful all-around player.",winner:"WINNER TO BE ANNOUNCED",mark:"✦"},
    {name:"Offensive Player",desc:"Celebrating elite offensive production.",winner:"WINNER TO BE ANNOUNCED",mark:"◆"},
    {name:"Defensive Player",desc:"Recognizing game-changing defensive work.",winner:"WINNER TO BE ANNOUNCED",mark:"⬟"},
    {name:"Rookie of the Year",desc:"Honoring a standout first season.",winner:"WINNER TO BE ANNOUNCED",mark:"★"}
  ]
};
const STORE_KEY = "ggl-football-demo-v2";
let data;
try { data = JSON.parse(localStorage.getItem(STORE_KEY)) || structuredClone(seed); }
catch { data = JSON.parse(JSON.stringify(seed)); }
let gameFilter = "all";
function persist(){ try{localStorage.setItem(STORE_KEY,JSON.stringify(data));}catch{} }
function safe(s){return String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function initials(s){return String(s||"?").trim().split(/\s+/).map(x=>x[0]).join("").slice(0,2).toUpperCase();}
function renderGames(){
  const list=data.games.filter(g=>gameFilter==="all"||g.status===gameFilter);
  document.getElementById("games").innerHTML=list.length?list.map(g=>{
    const final=g.status==="final";
    return `<article class="game-card"><div class="game-top"><span>${safe(g.week)}</span><span class="game-status ${final?"final":""}">${final?"FINAL":"UPCOMING"}</span></div><div class="matchup"><div class="side"><span class="logo">${safe(initials(g.away))}</span><strong>${safe(g.away)}</strong>${final?`<div class="score">${Number(g.awayScore)||0}</div>`:"<small>AWAY</small>"}</div><span class="versus">VS</span><div class="side"><span class="logo">${safe(initials(g.home))}</span><strong>${safe(g.home)}</strong>${final?`<div class="score">${Number(g.homeScore)||0}</div>`:"<small>HOME</small>"}</div></div><div class="game-bottom"><span>${safe(g.date)}</span><span>${final?"RESULT":"GGL LEAGUE"}</span></div></article>`;
  }).join(""):'<p class="footnote">No games in this filter yet.</p>';
}
function renderTeams(){
 document.getElementById("teamsGrid").innerHTML=data.teams.map(t=>`<article class="team-card"><span class="logo">${safe(t.short||initials(t.name))}</span><h3>${safe(t.name)}</h3><p>${safe(t.division||"GGL TEAM")}</p><div class="team-record">${Number(t.wins)||0} W&nbsp; / &nbsp;${Number(t.losses)||0} L</div></article>`).join("");
}
function renderPlayers(){
 const sorted=[...data.players].sort((a,b)=>(Number(b.yards)||0)-(Number(a.yards)||0));
 document.getElementById("playersBody").innerHTML=sorted.map((p,i)=>`<tr><td class="rank">${String(i+1).padStart(2,"0")}</td><td><span class="player-cell"><span class="avatar">${safe(initials(p.name))}</span><b>${safe(p.name)}</b></span></td><td>${safe(p.team)}</td><td>${safe(p.pos)}</td><td>${Number(p.yards)||0}</td><td>${Number(p.td)||0}</td><td>${Number(p.tackles)||0}</td></tr>`).join("");
}
function renderAwards(){document.getElementById("awardsGrid").innerHTML=data.awards.map(a=>`<article class="award-card"><div class="award-mark">${safe(a.mark||"★")}</div><h3>${safe(a.name)}</h3><p>${safe(a.desc)}</p><div class="award-winner">${safe(a.winner)}</div></article>`).join("");}
function render(){
 renderGames();renderTeams();renderPlayers();renderAwards();
 document.getElementById("teamTotal").textContent=String(data.teams.length).padStart(2,"0");
 document.getElementById("playerTotal").textContent=String(data.players.length).padStart(2,"0");
 document.getElementById("gameTotal").textContent=String(data.games.length).padStart(2,"0");
}
function toast(msg){const el=document.createElement("div");el.className="toast";el.textContent=msg;document.body.appendChild(el);setTimeout(()=>el.remove(),2800);}
document.getElementById("gameTabs").addEventListener("click",e=>{const b=e.target.closest("button[data-filter]");if(!b)return;gameFilter=b.dataset.filter;document.querySelectorAll("#gameTabs button").forEach(x=>x.classList.toggle("active",x===b));renderGames();});
document.getElementById("gameForm").addEventListener("submit",e=>{
 e.preventDefault();const f=new FormData(e.currentTarget);const a=f.get("awayScore"),h=f.get("homeScore");
 const hasScores=a!==""&&h!=="";
 data.games.unshift({week:f.get("week").trim(),date:f.get("date").trim(),away:f.get("away").trim().toUpperCase(),home:f.get("home").trim().toUpperCase(),awayScore:hasScores?Number(a):null,homeScore:hasScores?Number(h):null,status:hasScores?"final":"upcoming"});
 persist();render();e.currentTarget.reset();toast("Game added in this browser.");
});
document.getElementById("playerForm").addEventListener("submit",e=>{
 e.preventDefault();const f=new FormData(e.currentTarget);
 data.players.push({name:f.get("name").trim(),team:f.get("team").trim().toUpperCase(),pos:f.get("pos").trim().toUpperCase(),yards:Number(f.get("yards"))||0,td:Number(f.get("td"))||0,tackles:Number(f.get("tackles"))||0});
 persist();render();e.currentTarget.reset();toast("Player stat line added in this browser.");
});
document.getElementById("exportBtn").addEventListener("click",()=>{
 const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="ggl-league-data.json";a.click();URL.revokeObjectURL(url);toast("League data export started.");
});
document.getElementById("resetBtn").addEventListener("click",()=>{
 if(!confirm("Reset all local demo changes? This cannot be undone."))return;
 data=JSON.parse(JSON.stringify(seed));persist();render();toast("Demo data reset.");
});
const navToggle=document.getElementById("navToggle"),nav=document.getElementById("nav");
navToggle.addEventListener("click",()=>nav.classList.toggle("open"));
nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));
document.getElementById("year").textContent=new Date().getFullYear();
render();
