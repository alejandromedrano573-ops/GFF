# GGL Football — Black & Gold League Website

A responsive static website designed for GGL with:
- Game Center: sample upcoming matchups and final scores, with filters
- Team directory and win/loss records
- Player stat leaderboard
- Awards section
- Demo Admin Desk to add games and player stat lines, export JSON, and reset demo data
- Responsive mobile navigation and black-and-gold styling

## Quick start
1. Download and extract `ggl_football_v2.zip`.
2. Open `index.html` in a web browser to preview locally.
3. Customize sample records in `script.js` or use the demo Admin Desk.

## Publish with GitHub Pages
1. Sign in at https://github.com and create a new **public** repository, e.g. `ggl-football`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the root of the repository.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/(root)`, then click **Save**.
6. Wait for GitHub Pages to deploy. The Pages panel will show your public URL, usually `https://YOUR-USERNAME.github.io/ggl-football/`.

## Important limitations
- All team, player, schedule and score entries in this package are **demo data**. Replace them with real GGL data before sharing.
- “Live schedule and scores” here means a display for scores you enter. It does not connect to a live feed or automatically update from games.
- The Admin Desk is a browser-only demo. It saves changes in `localStorage` on that device/browser only. Visitors on other devices will not see those changes.
- This static site has no login, permissions, or database. Do not treat its Admin Desk as secure or enter private information.
- For a real shared admin system, connect a backend/database (such as Supabase or Firebase), set up authentication and access rules, and only then allow trusted staff to publish changes.
- The stadium background and fonts load from external providers, so an internet connection is needed for those assets.

## Customization pointers
- Change teams, games, player stats and awards in the `seed` object near the top of `script.js`.
- Change the Discord/community button or add your invite link in `index.html` if desired.
- Adjust colors in the CSS variables at the top of `style.css`.
